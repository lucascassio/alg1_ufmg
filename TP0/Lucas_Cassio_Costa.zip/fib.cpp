#include <iostream>
#include <chrono>

using namespace std;

long long int fib_iterative(int n) {
    long long int a = 0, b = 1, c;
    for (int i = 2; i <= n; ++i) {
        c = a + b;
        a = b;
        b = c;
    }
    return a;
}
long long int fib_recursive(int n, int time_limit, chrono::steady_clock::time_point start_time, int &last_calculated) {
    if (n <= 1) {
        last_calculated = n;
        return n;
    } else {
        long long int result = fib_recursive(n - 1, time_limit, start_time, last_calculated) + fib_recursive(n - 2, time_limit, start_time, last_calculated);
        if (chrono::duration_cast<chrono::seconds>(chrono::steady_clock::now() - start_time).count() >= time_limit) {
            last_calculated = n; // Atualiza o último número calculado antes de atingir o limite de tempo
        }
        return result;
    }
}

int main() {
    const int time_limits[] = {15, 30, 45, 60, 75, 90, 105, 120};

    for (int time_limit : time_limits) {
        auto start_time_recursive = chrono::steady_clock::now();

        int n_recursive = 0;
        int last_calculated_recursive = 0;
        while (chrono::duration_cast<chrono::seconds>(chrono::steady_clock::now() - start_time_recursive).count() < time_limit) {
            long long int result = fib_recursive(n_recursive, time_limit, start_time_recursive, last_calculated_recursive);
            n_recursive++;
        }

        auto end_time_recursive = chrono::steady_clock::now();

        auto start_time_iterative = chrono::steady_clock::now();

        int n_iterative = 0;
        while (chrono::duration_cast<chrono::seconds>(chrono::steady_clock::now() - start_time_iterative).count() < time_limit) {
            long long int result = fib_iterative(n_iterative);
            n_iterative++;
        }

        auto end_time_iterative = chrono::steady_clock::now();

        cout << "Time Limit (seconds): " << time_limit << endl;
        cout << "Recursive Fibonacci: " << last_calculated_recursive << " is the last number calculated within time limit" << endl;
        cout << "Iterative Fibonacci: " << n_iterative << " numbers generated" << endl;
        cout << endl;
    }

    return 0;
}
